# PollingRate Tester — macOS Hardware Mouse Polling Rate & Sync Benchmark

Designed by Hirbod

A high-precision, native macOS benchmarking suite engineered to measure genuine hardware mouse polling rates (125 Hz up to 8000 Hz) with sub-millisecond accuracy, advanced percentile statistics, real-time Live Speed (IPS), and diagnostic comparison across input layers.

---

## Key Features

* **Direct Kernel HID Acquisition**: Bypasses macOS WindowServer display synchronization to capture uncoalesced mouse packets directly from the IOKit driver.
* **4-Way Input Source Architecture**: Compare **Direct HID**, **Native HID**, **CoreGraphics Event Tap**, and **AppKit** in real time.
* **Live Mouse Speed (IPS) & Configurable CPI**: Real-time inches-per-second velocity measurement with stationary decay, peak tracking, and dynamic sensor CPI scaling (400–3200+ CPI).
* **Decoupled UI Presentation**: Independent render synchronization engine supporting VSync toggle and configurable UI FPS (60, 120, 240, or Unlimited) without artificially throttling the input measurement rate.
* **Full Percentile & Cadence Telemetry**: Real-time P50 (median), P90, P99 intervals, jitter standard deviation, burst detection, and cadence quality percentages (< 2.0 ms).
* **Multi-Source Fair Comparison Sheet**: Side-by-side diagnostic table with automated anomaly detection that flags suspiciously identical or mirrored event delivery between distinct OS layers.
* **Universal Binary**: Natively compiled for both **Apple Silicon (arm64)** and **Intel (x86_64)** Macs.
* **Pure Black Native UI**: Minimalist, high-contrast `#000000` aesthetic with real-time oscilloscope graph and visual motion arena.

---

## Multi-Source Pipeline Comparison

| Mode | Pipeline Architecture | Timestamp Source | Cadence Model |
| :--- | :--- | :--- | :--- |
| **Direct HID** | Kernel HID Element Broadcast (`IOHIDManager`) | Userspace `mach_absolute_time()` | Uncoalesced with 40 µs intra-packet multi-axis deduplication |
| **Native HID** | Targeted Physical Device (`IOHIDDeviceRef`) | Kernel driver interrupt timestamp (`IOHIDValueGetTimeStamp`) | Dedicated physical device stream bypassing broadcast |
| **CG Event Tap** | WindowServer Quartz Event Tap (`CGEventTap`) | `CGEventGetTimestamp()` | Session event queue; subject to WindowServer scheduling |
| **AppKit** | Cocoa WindowServer Compositor (`NSEvent`) | `NSEvent.timestamp` | Coalesced to display refresh rate (~60 Hz / VSync) |

---

## Installation & Downloads

Pre-built release packages are available in the [`release/`](file:///Users/hirbod/.gemini/antigravity/scratch/mouse-polling-rate-tester/release/) directory:

| Asset | Format | Description |
| :--- | :--- | :--- |
| **[PollingRateTester-v1.0.0.dmg](file:///Users/hirbod/.gemini/antigravity/scratch/mouse-polling-rate-tester/release/PollingRateTester-v1.0.0.dmg)** | Apple Disk Image (`.dmg`) | Drag-and-drop installer for macOS with `/Applications` link |
| **[PollingRateTester-v1.0.0-macOS.zip](file:///Users/hirbod/.gemini/antigravity/scratch/mouse-polling-rate-tester/release/PollingRateTester-v1.0.0-macOS.zip)** | Standalone Application (`.zip`) | Portable app bundle preserving extended attributes and code sign |
| **[pollingrate-tester-cli-v1.0.0-macOS.tar.gz](file:///Users/hirbod/.gemini/antigravity/scratch/mouse-polling-rate-tester/release/pollingrate-tester-cli-v1.0.0-macOS.tar.gz)** | Terminal CLI Archive (`.tar.gz`) | Standalone Universal command-line benchmark tool |
| **[SHA256SUMS.txt](file:///Users/hirbod/.gemini/antigravity/scratch/mouse-polling-rate-tester/release/SHA256SUMS.txt)** | Checksums | Cryptographic SHA-256 validation hashes for all artifacts |

### Installing the `.dmg`:
1. Download and open `PollingRateTester-v1.0.0.dmg`.
2. Drag **PollingRateTester** into your **Applications** folder.
3. If macOS Gatekeeper prompts on first launch (for unsigned/ad-hoc signed builds), run:
   ```bash
   xattr -cr /Applications/PollingRateTester.app
   ```
4. On macOS Catalina and later, ensure **Input Monitoring** permission is granted when prompted (or in **System Settings > Privacy & Security > Input Monitoring**).

---

## Building from Source

### Prerequisites
* macOS 12.0 or later
* Xcode Command Line Tools (`xcode-select --install`)
* Clang with Apple Silicon and Intel SDKs

### Quick Build & Run
```bash
# Build the universal app bundle
make app

# Launch the app
make run

# Build the standalone CLI binary
make cli

# Run the 10-point architectural validation suite
make test

# Generate a complete release package (DMG, ZIP, CLI tarball, SHA-256 sums)
make release
```

---

## CLI Usage

Run high-frequency command-line benchmarks directly in your terminal:

```bash
# Benchmark with Direct Kernel HID (default, 1000 Hz)
./build/pollingrate-tester --source directhid --cpi 800

# Benchmark with Native Targeted HID
./build/pollingrate-tester --source nativehid --cpi 800

# Compare against CoreGraphics session tap
./build/pollingrate-tester --source cgtap

# Compare against AppKit (shows 60 Hz display coalescing)
./build/pollingrate-tester --source appkit

# Test with VSync disabled and custom rendering FPS
./build/pollingrate-tester --source directhid --vsync off --fps 240
```

---

## Automated Architectural Test Suite

Run `make test` to execute the built-in test harness verifying:
1. Pointing device enumeration and IOKit metadata resolution
2. 1000 Hz statistical math engine, median (P50), P90, P99, and jitter calculations
3. WindowServer 60 Hz coalescing anomaly detection
4. Render loop decoupling (FPS independent of input acquisition)
5. Direct HID kernel subsystem startup and callback handling
6. Live Mouse Speed (IPS) formula across stationary, slow, fast, decay, and CPI scaling
7. Native HID subsystem lifecycle and targeted device binding
8. 2000 Hz sub-millisecond monotonic timestamping
9. Multi-source state isolation across all 4 independent engines
10. Fair comparison engine and suspicious duplicate delivery detection

---

## License & Credits

Designed by Hirbod.
Distributed under the MIT License.
